<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Is Hodor still deaf?</title>
        <style>
            table{
                padding: 10px;
                border-collapse: collapse;
            }
            th, td {
                padding: 7px;
            }
        </style>
    </head>

    <body>
    <center>  
        <h1>Is hodor still deaf?</h1>
        <form action="result.php" method="POST">
         <table>
            <tr>
                <td>Fill in your name :</td>
                <td><input type="text" name="name" required></td>
                <td rowspan=1><input type="submit" value="Submit"></td>
            </tr>
         </table>
        </form>

    </center>
    </body>
</html>