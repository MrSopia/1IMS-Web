
<div class="navigation-bar">
    <div id="navigation-container">
        <a href="./index.php"><img class="logo" src="./images/NoTtinderlogo.png"></a>
            
        <ul>
            <li><a href="./index.php">Home</a></li>
            <li><a href="./create.php">Create Profile</a></li>
            <li><a href="./swipetemp.php">Swipe</a></li>
            <li><a href="./drop.php">Drop Relations</a></li>
        </ul>
    </div>
</div>