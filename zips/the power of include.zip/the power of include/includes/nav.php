<div class="header">
    <button class="button" onclick="document.location='index.php'">home</button>
    <div class="divider"></div>
    <button class="button" onclick="document.location='about.php'">about</button>
    <div class="divider"></div>
    <button class="button" onclick="document.location='contact.php'">services</button>
    <div class="divider"></div>
    <button class="button" onclick="document.location='services.php'">contact</button>
</div>