<div class="footer">
    <span id="footertext">Contact me please</span>
    <br>
    <span id="footertext">Copyright by me</span>
</div>