<!DOCTYPE html>
<html>
    <head>
        <title>contact</title>
        <link rel="stylesheet" href="./style.css" type="text/css">
    </head>
    <body>
        <div class="container">
            <div class="vertdivider"></div>
            <?php
                include "./includes/nav.php";
            ?>
            <div class="vertdivider"></div>
            <div class="main">
                <h1>contact</h1>
            </div>
            <div class="vertdivider"></div>
            <?php
                include "./includes/footer.php";
            ?>
        </div>
    </body>
</html>