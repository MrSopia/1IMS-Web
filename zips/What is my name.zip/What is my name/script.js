var name = prompt("Fill in your name");

for (var i = 0; i < name.length; i++) {
    alert(name.charAt(i));
  }