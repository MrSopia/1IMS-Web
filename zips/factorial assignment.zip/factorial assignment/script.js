var f = 1;
var number = prompt("give factorial number");

for (i = 1; i <= number; i++)
{
    f = f * i;
}

alert(f);